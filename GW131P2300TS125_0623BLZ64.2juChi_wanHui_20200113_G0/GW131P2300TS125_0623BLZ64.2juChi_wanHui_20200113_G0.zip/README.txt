==== D0: (2020-01-13) =====
├─原始控制器:
    ├─GW131P23TS125_404BLz64.2V10_CFII_V4.01.dll
    └─GW131P23TS125_404BLz64.2V10_CFII_V4.01.xml

调参说明：
	
参数变动：
	P_OptimalModeGain: 806477 -> 1133000
	P_MinimumFinePitch: 0 -> 0.008727
	P_SteadyShaftPowerLimit: 2595500 -> 2595521.5
	P_TowerExcLowSpeed: 0.8468 -> 0.95295
	P_TowerExcHighSpeed: 0.9941 -> 1.05767
	P_TowerExcLowSpeedMaxTorque: 635530 -> 1080337
	P_TowerExcHighSpeedMinTorque: 485073 -> 83432
	P_NacelleAccFAEnabled: false -> true
	F_PitchSpeedFilters[1][Numerator_Frequency]: 0.92 -> 1
	F_PitchSpeedFilters[1][Denominator_Frequency]: 0.92 -> 1
	F_TorqueSpeedFilters[1][Numerator_Frequency]: 0.92 -> 1
	F_TorqueSpeedFilters[1][Denominator_Frequency]: 0.92 -> 1
	F_ConstantPowerFilters[1][Numerator_Frequency]: 0.92 -> 1
	F_ConstantPowerFilters[1][Denominator_Frequency]: 0.92 -> 1
	