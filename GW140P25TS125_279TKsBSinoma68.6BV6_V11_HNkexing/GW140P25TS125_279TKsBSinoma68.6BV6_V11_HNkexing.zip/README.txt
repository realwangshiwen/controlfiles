==== D0: (2020-01-13) =====
├─原始控制器:
    ├─GW140P2500TS140_1327KsBSinoma68.6BV6_V11_CFII_V6.01.01.dll
    └─GW140P2500TS140_1327KsBSinoma68.6BV6_V11_CFII_V6.01.01.xml

调参说明：
	
参数变动：
	P_OptimalModeGain: 1.27E+06 -> 1287000
	P_TowerExcLowSpeed: 0.832 -> 0.98764
	P_TowerExcHighSpeed: 0.977 -> 1.09236
	P_TowerExcLowSpeedMaxTorque: 968459 -> 1318151
	P_TowerExcHighSpeedMinTorque: 739183 -> 102153
	T_DynamicFinePitch[1][2]: 0.0349 -> 0.0567
	T_DynamicFinePitch[1][3]: 0.0698 -> 0.0907
	T_DynamicFinePitch[1][4]: 0.0873 -> 0.1134
	T_DynamicFinePitch[1][5]: 0.1047 -> 0.2268
	F_PitchSpeedFilters[1][Numerator_Frequency]: 0.905 -> 1.04
	F_PitchSpeedFilters[1][Denominator_Frequency]: 0.905 -> 1.04
	F_TorqueSpeedFilters[1][Numerator_Frequency]: 0.905 -> 1.04
	F_TorqueSpeedFilters[1][Denominator_Frequency]: 0.905 -> 1.04
	F_ConstantPowerFilters[1][Numerator_Frequency]: 0.905 -> 1.04
	F_ConstantPowerFilters[1][Denominator_Frequency]: 0.905 -> 1.04
	